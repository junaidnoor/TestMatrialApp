package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 12/3/2015.
 */
public class RadiologyResult {

    private String detail;
    private String conclusion;
    private String heading;

    public String getDetail() {
        return detail;
    }

    public void setDetail(String detail) {
        this.detail = detail;
    }

    public String getConclusion() {
        return conclusion;
    }

    public void setConclusion(String conclusion) {
        this.conclusion = conclusion;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }
}
