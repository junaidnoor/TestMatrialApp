package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 10/3/2015.
 */
public class IRS {
    private String mr_code;
    private String irs;
    private String test_count;

    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getIrs() {
        return irs;
    }

    public void setIrs(String irs) {
        this.irs = irs;
    }

    public String getTest_count() {
        return test_count;
    }

    public void setTest_count(String test_count) {
        this.test_count = test_count;
    }

    /*
    @Override
    public String getPat_fname() {
        return super.getPat_fname();
    }

    @Override
    public void setPat_fname(String pat_fname) {
        super.setPat_fname(pat_fname);
    }

    @Override
    public String getMr_code() {
        return super.getMr_code();
    }

    @Override
    public void setMr_code(String mr_code) {
        super.setMr_code(mr_code);
    }

    @Override
    public String getPat_name() {
        return super.getPat_name();
    }

    @Override
    public void setPat_name(String pat_name) {
        super.setPat_name(pat_name);
    }

    @Override
    public String getPat_age() {
        return super.getPat_age();
    }

    @Override
    public void setPat_age(String pat_age) {
        super.setPat_age(pat_age);
    }

    @Override
    public String getPat_sex() {
        return super.getPat_sex();
    }

    @Override
    public void setPat_sex(String pat_sex) {
        super.setPat_sex(pat_sex);
    }
    */
}
