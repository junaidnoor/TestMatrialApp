package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 11/14/2015.
 */
public class MicroResultOrg {

    private String parameter;;
    private String org1;
    private String org2;
    private String org3;

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getOrg1() {
        return org1;
    }

    public void setOrg1(String org1) {
        this.org1 = org1;
    }

    public String getOrg2() {
        return org2;
    }

    public void setOrg2(String org2) {
        this.org2 = org2;
    }

    public String getOrg3() {
        return org3;
    }

    public void setOrg3(String org3) {
        this.org3 = org3;
    }
}
