package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 11/10/2015.
 */
public class NormalResult {

    private String mr_code;
    private String lrs_no;
    private String adm_no;
    private String parameter;
    private String normal_value;
    private String result;
    private String remarks;


    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getLrs_no() {
        return lrs_no;
    }

    public void setLrs_no(String lrs_no) {
        this.lrs_no = lrs_no;
    }

    public String getAdm_no() {
        return adm_no;
    }

    public void setAdm_no(String adm_no) {
        this.adm_no = adm_no;
    }

    public String getParameter() {
        return parameter;
    }

    public void setParameter(String parameter) {
        this.parameter = parameter;
    }

    public String getNormal_value() {
        return normal_value;
    }

    public void setNormal_value(String normal_value) {
        this.normal_value = normal_value;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
