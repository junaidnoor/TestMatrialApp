package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 10/28/2015.
 */
public class Employee {

    private String emp_code;
    private String emp_name;
    private String emp_userid;
    private String emp_specility;
    private String emp_designation;
    private String isvalid;
    private int empImgReosurce;
    private String msstat;

    public String getEmp_code() {
        return emp_code;
    }

    public void setEmp_code(String emp_code) {
        this.emp_code = emp_code;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    public String getEmp_userid() {
        return emp_userid;
    }

    public void setEmp_userid(String emp_userid) {
        this.emp_userid = emp_userid;
    }

    public String getEmp_specility() {
        return emp_specility;
    }

    public void setEmp_specility(String emp_specility) {
        this.emp_specility = emp_specility;
    }

    public String getEmp_designation() {
        return emp_designation;
    }

    public void setEmp_designation(String emp_designation) {
        this.emp_designation = emp_designation;
    }

    public String getIsvalid() {
        return isvalid;
    }

    public void setIsvalid(String isvalid) {
        this.isvalid = isvalid;
    }

    public int getEmpImgReosurce() {
        return empImgReosurce;
    }

    public void setEmpImgReosurce(int empImgReosurce) {
        this.empImgReosurce = empImgReosurce;
    }

    public String getMsstat() {
        return msstat;
    }

    public void setMsstat(String msstat) {
        this.msstat = msstat;
    }
}
