package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 10/24/2015.
 */
import android.view.View;

/**
 * Created by alex on 5/6/15.
 */
public interface ItemClickListener {

    void onClick(View view, int position, boolean isLongClick);

}
