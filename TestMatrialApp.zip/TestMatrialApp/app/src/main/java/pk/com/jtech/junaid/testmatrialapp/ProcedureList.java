package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 11/3/2015.
 */
public class ProcedureList {

    private String mr_code;
    private String adm_no;
    private String op_date;
    private String porcedure_code;
    private String procedure;
    private String surg_code;
    private String surg;
    private String oper_date_time;


    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getAdm_no() {
        return adm_no;
    }

    public void setAdm_no(String adm_no) {
        this.adm_no = adm_no;
    }

    public String getOp_date() {
        return op_date;
    }

    public void setOp_date(String op_date) {
        this.op_date = op_date;
    }

    public String getPorcedure_code() {
        return porcedure_code;
    }

    public void setPorcedure_code(String porcedure_code) {
        this.porcedure_code = porcedure_code;
    }

    public String getProcedure() {
        return procedure;
    }

    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public String getSurg_code() {
        return surg_code;
    }

    public void setSurg_code(String surg_code) {
        this.surg_code = surg_code;
    }

    public String getSurg() {
        return surg;
    }

    public void setSurg(String surg) {
        this.surg = surg;
    }

    public String getOper_date_time() {
        return oper_date_time;
    }

    public void setOper_date_time(String oper_date_time) {
        this.oper_date_time = oper_date_time;
    }
}
