package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 11/13/2015.
 */
public class MicroResultSatin {

    private String stain;
    private String stain_value;


    public String getStain() {
        return stain;
    }

    public void setStain(String stain) {
        this.stain = stain;
    }

    public String getStain_value() {
        return stain_value;
    }

    public void setStain_value(String stain_value) {
        this.stain_value = stain_value;
    }
}
