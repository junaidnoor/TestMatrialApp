package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 10/5/2015.
 */
public class GroupDetail {

    private String mr_code;
    private String lrs_no;
    private String entry_time;
    private String test_code;
    private String test_name;
    private String adm_no;
    private String group_name;
    private String org1;
    private String org2;
    private String org3;
    private String remarks;
    private String group_code;
    private String report_id;


    public String getReport_id() {
        return report_id;
    }

    public void setReport_id(String report_id) {
        this.report_id = report_id;
    }

    public String getGroup_code() {
        return group_code;
    }

    public void setGroup_code(String group_code) {
        this.group_code = group_code;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getOrg1() {
        return org1;
    }

    public void setOrg1(String org1) {
        this.org1 = org1;
    }

    public String getOrg2() {
        return org2;
    }

    public void setOrg2(String org2) {
        this.org2 = org2;
    }

    public String getOrg3() {
        return org3;
    }

    public void setOrg3(String org3) {
        this.org3 = org3;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getAdm_no() {
        return adm_no;
    }

    public void setAdm_no(String adm_no) {
        this.adm_no = adm_no;
    }

    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getLrs_no() {
        return lrs_no;
    }

    public void setLrs_no(String lrs_no) {
        this.lrs_no = lrs_no;
    }

    public String getEntry_time() {
        return entry_time;
    }

    public void setEntry_time(String entry_time) {
        this.entry_time = entry_time;
    }

    public String getTest_code() {
        return test_code;
    }

    public void setTest_code(String test_code) {
        this.test_code = test_code;
    }

    public String getTest_name() {
        return test_name;
    }

    public void setTest_name(String test_name) {
        this.test_name = test_name;
    }
}
