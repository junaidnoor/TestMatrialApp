package pk.com.jtech.junaid.testmatrialapp;

import android.graphics.Bitmap;

/**
 * Created by Junaid on 8/26/2015.
 */
public class GroupList {


    private String mr_code;
    private String group_code;
    private String group_name;
    private String test_count;
    private int imgReosurce;


    public String getMr_code() { return mr_code; }

    public void setMr_code(String mr_code) { this.mr_code = mr_code; }

    public String getGroup_code() { return group_code; }

    public void setGroup_code(String group_code) { this.group_code = group_code; }

    public String getGroup_name() { return group_name; }

    public void setGroup_name(String group_name) { this.group_name = group_name; }

    public String getTest_count() { return test_count; }

    public void setTest_count(String test_count) { this.test_count = test_count; }

    public int getImgReosurce() { return imgReosurce; }

    public void setImgReosurce(int imgReosurce) { this.imgReosurce = imgReosurce; }

    /*
        @Override
        public String getMr_code() {
            return super.getMr_code();
        }


        @Override
        public void setMr_code(String mr_code) {
            super.setMr_code(mr_code);
        }

        @Override
        public String getPat_name() {
            return super.getPat_name();
        }

        @Override
        public void setPat_name(String pat_name) {
            super.setPat_name(pat_name);
        }

        @Override
        public String getPat_fname() {
            return super.getPat_fname();
        }

        @Override
        public void setPat_fname(String pat_fname) {
            super.setPat_fname(pat_fname);
        }

        @Override
        public String getPat_age() {
            return super.getPat_age();
        }

        @Override
        public void setPat_age(String pat_age) {
            super.setPat_age(pat_age);
        }

        @Override
        public String getPat_sex() {
            return super.getPat_sex();
        }

        @Override
        public void setPat_sex(String pat_sex) {
            super.setPat_sex(pat_sex);
        }
*/

}
