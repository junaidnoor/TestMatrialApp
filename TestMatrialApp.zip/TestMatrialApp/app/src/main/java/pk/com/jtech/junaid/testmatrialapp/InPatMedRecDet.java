package pk.com.jtech.junaid.testmatrialapp;

/**
 * Created by Junaid on 11/7/2015.
 */
public class InPatMedRecDet {

    private String mr_code;
    private String title;
    private String mrdata;

    private String title2;
    private String mrdata2;
    private String mrdata3;

    public String getMrdata3() {
        return mrdata3;
    }

    public void setMrdata3(String mrdata3) {
        this.mrdata3 = mrdata3;
    }

    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMrdata() {
        return mrdata;
    }

    public void setMrdata(String mrdata) {
        this.mrdata = mrdata;
    }

    public String getTitle2() {
        return title2;
    }

    public void setTitle2(String title2) {
        this.title2 = title2;
    }

    public String getMrdata2() {
        return mrdata2;
    }

    public void setMrdata2(String mrdata2) {
        this.mrdata2 = mrdata2;
    }
}
