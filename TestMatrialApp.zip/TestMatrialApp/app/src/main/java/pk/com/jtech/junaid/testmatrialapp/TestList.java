package pk.com.jtech.junaid.testmatrialapp;

import android.graphics.Bitmap;

/**
 * Created by Junaid on 8/23/2015.
 */
public class TestList {

    private String mr_code;
    //private String pat_name;
    private String test_code;
    private String test_name;
    private String group_code;
    private String group_name;
    private String irs;
    private String test_count;
    private int imgReosurce;

    public String getMr_code() {
        return mr_code;
    }

    public void setMr_code(String mr_code) {
        this.mr_code = mr_code;
    }

    public String getTest_code() {
        return test_code;
    }

    public void setTest_code(String test_code) {
        this.test_code = test_code;
    }

    public String getTest_name() {
        return test_name;
    }

    public void setTest_name(String test_name) {
        this.test_name = test_name;
    }

    public String getGroup_code() {
        return group_code;
    }

    public void setGroup_code(String group_code) {
        this.group_code = group_code;
    }

    public String getGroup_name() {
        return group_name;
    }

    public void setGroup_name(String group_name) {
        this.group_name = group_name;
    }

    public String getIrs() {
        return irs;
    }

    public void setIrs(String irs) {
        this.irs = irs;
    }

    public String getTest_count() {
        return test_count;
    }

    public void setTest_count(String test_count) {
        this.test_count = test_count;
    }

    public int getImgReosurce() {
        return imgReosurce;
    }

    public void setImgReosurce(int imgReosurce) {
        this.imgReosurce = imgReosurce;
    }


/*
    @Override
    public String getPat_name() {
        return super.getPat_name();
    }

    @Override
    public void setPat_name(String pat_name) {
        super.setPat_name(pat_name);
    }

    */


}
